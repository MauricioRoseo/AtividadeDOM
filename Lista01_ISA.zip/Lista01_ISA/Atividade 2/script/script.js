const btnRed = document.getElementById('btnRed');
const btnGreen = document.getElementById('btnGreen');
const btnBlue = document.getElementById('btnBlue');
const body = document.body;

btnRed.addEventListener('click', function() {
    body.style.backgroundColor = 'red';
});

btnGreen.addEventListener('click', function() {
    body.style.backgroundColor = 'green';
});

btnBlue.addEventListener('click', function() {
    body.style.backgroundColor = 'blue';
});
