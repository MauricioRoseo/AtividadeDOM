const c = (el) => document.querySelector(el);
const cs = (el) => document.querySelectorAll(el);

function calcimc() {
    let peso = Number(c('.peso').value);
    let altura = Number(c('.altura').value);
    let imc = peso / (altura * altura);

    if (imc < 18.5) {
        c(".text-body").innerHTML = 'Abaixo do peso adequado: ' + imc.toFixed(1);
        c(".text-body").style.display = "flex"
    } else if (imc >= 18.5 && imc < 24.9) {
        c(".text-body").innerHTML = 'Na média de peso adequada: ' + imc.toFixed(1);
        c(".text-body").style.display = "flex"
    } else if (imc >= 25 && imc < 29.9) {
        c(".text-body").innerHTML = 'Acima do peso adequado: ' + imc.toFixed(1);
        c(".text-body").style.display = "flex"
    } else if (imc >= 30 && imc < 39.9) {
        c(".text-body").innerHTML = 'Você está no quadro de Obesidade, Cuidado! ' + imc.toFixed(1);
        c(".text-body").style.display = "flex"
    } else if (imc >= 40) {
        c(".text-body").innerHTML = 'Você está no quadro de Obesidade Grave, Busque auxilio médico: ' + imc.toFixed(1);
        c(".text-body").style.display = "flex"
    } else {
        c(".text-body").innerHTML = 'Algo de errado não está certo! Por favor reinsira com valores aceitáveis';
        c(".text-body").style.display = "flex"
    }
}

c('.button').addEventListener('click', calcimc);
